package com.example.ui.screens

import android.annotation.SuppressLint
import android.graphics.Bitmap
import android.net.http.SslError
import android.view.ViewGroup
import android.webkit.CookieManager
import android.webkit.SslErrorHandler
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.automirrored.rounded.OpenInNew
import androidx.compose.material.icons.rounded.CloudOff
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import com.example.R
import com.example.ui.PortalUiState
import com.example.ui.components.PoweredByFooter
import com.example.ui.components.openUrlInExternalBrowser
import com.example.ui.theme.KpkRoyalBlue
import com.example.ui.theme.KpkWhite

@SuppressLint("SetJavaScriptEnabled")
@Composable
fun PortalScreen(
  uiState: PortalUiState,
  initialUrl: String,
  onNavigateHome: () -> Unit,
  onProgressChanged: (Int) -> Unit,
  onPageStateChanged: (url: String?, title: String?, canGoBack: Boolean) -> Unit,
  onWebError: (String) -> Unit,
  onRetry: () -> Unit,
  modifier: Modifier = Modifier,
) {
  val context = LocalContext.current
  var webViewRef by remember { mutableStateOf<WebView?>(null) }

  BackHandler {
    val webView = webViewRef
    if (webView != null && webView.canGoBack()) {
      webView.goBack()
    } else {
      onNavigateHome()
    }
  }

  LaunchedEffect(uiState.reloadTrigger) {
    if (uiState.reloadTrigger > 0) {
      webViewRef?.let { wv ->
        if (wv.url.isNullOrBlank()) {
          wv.loadUrl(initialUrl)
        } else {
          wv.reload()
        }
      }
    }
  }

  DisposableEffect(Unit) {
    onDispose {
      webViewRef?.apply {
        stopLoading()
        destroy()
      }
      webViewRef = null
    }
  }

  Scaffold(
    modifier = modifier.fillMaxSize(),
    containerColor = MaterialTheme.colorScheme.background,
    topBar = {
      Surface(color = KpkRoyalBlue, shadowElevation = 4.dp) {
        Column(modifier = Modifier.fillMaxWidth().statusBarsPadding()) {
          Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
          ) {
            IconButton(
              onClick = {
                val webView = webViewRef
                if (webView != null && webView.canGoBack()) {
                  webView.goBack()
                } else {
                  onNavigateHome()
                }
              },
              modifier = Modifier.minimumInteractiveComponentSize().testTag("portal_back_button"),
            ) {
              Icon(
                imageVector = Icons.AutoMirrored.Rounded.ArrowBack,
                contentDescription = stringResource(R.string.action_back),
                tint = KpkWhite,
              )
            }

            Column(modifier = Modifier.weight(1f).padding(horizontal = 4.dp)) {
              Text(
                text =
                  uiState.pageTitle.takeIf { it.isNotBlank() }
                    ?: stringResource(R.string.portal_top_bar_title),
                style = MaterialTheme.typography.titleMedium,
                color = KpkWhite,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
              )
              Text(
                text = uiState.currentUrl,
                style = MaterialTheme.typography.labelSmall,
                color = Color(0xFFD6E7FF),
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
              )
            }

            IconButton(
              onClick = onRetry,
              modifier = Modifier.minimumInteractiveComponentSize().testTag("portal_refresh_button"),
            ) {
              Icon(
                imageVector = Icons.Rounded.Refresh,
                contentDescription = stringResource(R.string.action_refresh),
                tint = KpkWhite,
              )
            }

            IconButton(
              onClick = { openUrlInExternalBrowser(context, uiState.currentUrl) },
              modifier =
                Modifier.minimumInteractiveComponentSize().testTag("portal_external_button"),
            ) {
              Icon(
                imageVector = Icons.AutoMirrored.Rounded.OpenInNew,
                contentDescription = stringResource(R.string.open_external_browser),
                tint = KpkWhite,
              )
            }

            IconButton(
              onClick = onNavigateHome,
              modifier = Modifier.minimumInteractiveComponentSize().testTag("portal_home_button"),
            ) {
              Icon(
                imageVector = Icons.Rounded.Home,
                contentDescription = stringResource(R.string.action_home),
                tint = KpkWhite,
              )
            }
          }

          AnimatedVisibility(visible = uiState.isLoading) {
            LinearProgressIndicator(
              progress = { (uiState.loadProgress / 100f).coerceIn(0.05f, 1f) },
              modifier = Modifier.fillMaxWidth().height(3.dp),
              color = Color(0xFFFFD54F),
              trackColor = KpkRoyalBlue,
            )
          }
        }
      }
    },
    bottomBar = { PoweredByFooter(applyNavBarInsets = true) },
  ) { innerPadding ->
    Box(modifier = Modifier.fillMaxSize().padding(innerPadding)) {
      AndroidView(
        modifier = Modifier.fillMaxSize().testTag("pifra_webview"),
        factory = { viewContext ->
          WebView(viewContext).apply {
            layoutParams =
              ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT,
              )

            val cookieManager = CookieManager.getInstance()
            cookieManager.setAcceptCookie(true)
            cookieManager.setAcceptThirdPartyCookies(this, true)

            settings.apply {
              javaScriptEnabled = true
              domStorageEnabled = true
              loadsImagesAutomatically = true
              useWideViewPort = true
              loadWithOverviewMode = true
              setSupportZoom(true)
              builtInZoomControls = true
              displayZoomControls = false
              mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
              cacheMode = WebSettings.LOAD_DEFAULT
            }

            setDownloadListener { downloadUrl, _, _, _, _ ->
              if (!downloadUrl.isNullOrBlank()) {
                openUrlInExternalBrowser(viewContext, downloadUrl)
              }
            }

            webChromeClient =
              object : WebChromeClient() {
                override fun onProgressChanged(view: WebView?, newProgress: Int) {
                  onProgressChanged(newProgress)
                }

                override fun onReceivedTitle(view: WebView?, title: String?) {
                  onPageStateChanged(view?.url, title, view?.canGoBack() ?: false)
                }
              }

            webViewClient =
              object : WebViewClient() {
                override fun shouldOverrideUrlLoading(
                  view: WebView?,
                  request: WebResourceRequest?,
                ): Boolean {
                  val uri = request?.url ?: return false
                  val scheme = uri.scheme?.lowercase().orEmpty()
                  return if (scheme == "http" || scheme == "https") {
                    false
                  } else {
                    openUrlInExternalBrowser(viewContext, uri.toString())
                    true
                  }
                }

                override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
                  onProgressChanged(15)
                }

                override fun onPageFinished(view: WebView?, url: String?) {
                  onPageStateChanged(url, view?.title, view?.canGoBack() ?: false)
                }

                override fun onReceivedError(
                  view: WebView?,
                  request: WebResourceRequest?,
                  error: WebResourceError?,
                ) {
                  if (request?.isForMainFrame == true) {
                    val desc = error?.description?.toString().orEmpty()
                    onWebError(
                      desc.ifBlank { viewContext.getString(R.string.portal_error_message) }
                    )
                  }
                }

                override fun onReceivedSslError(
                  view: WebView?,
                  handler: SslErrorHandler?,
                  error: SslError?,
                ) {
                  handler?.cancel()
                  onWebError(viewContext.getString(R.string.portal_error_message))
                }
              }

            webViewRef = this
            loadUrl(initialUrl)
          }
        },
        update = { webView -> webViewRef = webView },
      )

      if (uiState.errorMessage != null) {
        Box(
          modifier =
            Modifier
              .fillMaxSize()
              .background(MaterialTheme.colorScheme.background.copy(alpha = 0.96f))
              .padding(24.dp),
          contentAlignment = Alignment.Center,
        ) {
          Card(
            modifier = Modifier.fillMaxWidth(),
            shape = MaterialTheme.shapes.large,
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
            elevation = CardDefaults.cardElevation(defaultElevation = 4.dp),
          ) {
            Column(
              modifier = Modifier.fillMaxWidth().padding(24.dp),
              horizontalAlignment = Alignment.CenterHorizontally,
              verticalArrangement = Arrangement.spacedBy(12.dp),
            ) {
              Icon(
                imageVector = Icons.Rounded.CloudOff,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(48.dp),
              )
              Text(
                text = stringResource(R.string.portal_error_title),
                style = MaterialTheme.typography.titleLarge,
                color = MaterialTheme.colorScheme.onSurface,
                textAlign = TextAlign.Center,
              )
              Text(
                text = stringResource(R.string.portal_error_message),
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = TextAlign.Center,
              )
              Spacer(modifier = Modifier.height(4.dp))
              Button(
                onClick = onRetry,
                modifier =
                  Modifier.fillMaxWidth().heightIn(min = 48.dp).testTag("portal_retry_button"),
                shape = RoundedCornerShape(12.dp),
              ) {
                Icon(
                  imageVector = Icons.Rounded.Refresh,
                  contentDescription = null,
                  modifier = Modifier.size(18.dp),
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(text = stringResource(R.string.action_retry))
              }
              OutlinedButton(
                onClick = { openUrlInExternalBrowser(context, uiState.currentUrl) },
                modifier =
                  Modifier
                    .fillMaxWidth()
                    .heightIn(min = 48.dp)
                    .testTag("portal_error_open_browser_button"),
                shape = RoundedCornerShape(12.dp),
              ) {
                Icon(
                  imageVector = Icons.AutoMirrored.Rounded.OpenInNew,
                  contentDescription = null,
                  modifier = Modifier.size(18.dp),
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(text = stringResource(R.string.open_external_browser))
              }
            }
          }
        }
      }
    }
  }
}
