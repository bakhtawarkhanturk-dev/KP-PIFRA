package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowForward
import androidx.compose.material.icons.automirrored.rounded.HelpOutline
import androidx.compose.material.icons.automirrored.rounded.OpenInNew
import androidx.compose.material.icons.rounded.AccountBalance
import androidx.compose.material.icons.rounded.Description
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.Public
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.ui.PifraViewModel
import com.example.ui.components.KpkGovernmentHeroHeader
import com.example.ui.components.PoweredByFooter
import com.example.ui.components.openUrlInExternalBrowser

@Composable
fun HomeScreen(
  onEnterPortal: () -> Unit,
  onOpenGuide: () -> Unit,
  modifier: Modifier = Modifier,
) {
  val context = LocalContext.current

  Scaffold(
    modifier = modifier.fillMaxSize(),
    containerColor = MaterialTheme.colorScheme.background,
    bottomBar = { PoweredByFooter(applyNavBarInsets = true) },
  ) { innerPadding ->
    Column(
      modifier =
        Modifier
          .fillMaxSize()
          .padding(bottom = innerPadding.calculateBottomPadding())
          .verticalScroll(rememberScrollState()),
      horizontalAlignment = Alignment.CenterHorizontally,
    ) {
      KpkGovernmentHeroHeader()

      BoxWithConstraints(
        modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 20.dp),
        contentAlignment = Alignment.TopCenter,
      ) {
        val isWide = maxWidth >= 600.dp
        Column(
          modifier = Modifier.widthIn(max = 640.dp).fillMaxWidth(),
          verticalArrangement = Arrangement.spacedBy(16.dp),
        ) {
          PrimaryPortalCard(
            onEnterPortal = onEnterPortal,
            onOpenExternal = {
              openUrlInExternalBrowser(context, PifraViewModel.PIFRA_DDO_ALV_URL)
            },
            onOpenGuide = onOpenGuide,
          )

          Text(
            text = stringResource(R.string.quick_services_heading),
            style = MaterialTheme.typography.titleMedium,
            color = MaterialTheme.colorScheme.onBackground,
            modifier = Modifier.padding(top = 4.dp),
          )

          if (isWide) {
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.spacedBy(12.dp),
            ) {
              ServiceItemCard(
                icon = Icons.Rounded.AccountBalance,
                title = stringResource(R.string.service_ddo_title),
                description = stringResource(R.string.service_ddo_desc),
                onClick = onEnterPortal,
                testTag = "service_ddo_card",
                modifier = Modifier.weight(1f),
              )
              ServiceItemCard(
                icon = Icons.Rounded.Description,
                title = stringResource(R.string.service_payslip_title),
                description = stringResource(R.string.service_payslip_desc),
                onClick = onEnterPortal,
                testTag = "service_payslip_card",
                modifier = Modifier.weight(1f),
              )
            }
            ServiceItemCard(
              icon = Icons.Rounded.Lock,
              title = stringResource(R.string.service_security_title),
              description = stringResource(R.string.service_security_desc),
              onClick = onOpenGuide,
              testTag = "service_security_card",
              modifier = Modifier.fillMaxWidth(),
            )
          } else {
            ServiceItemCard(
              icon = Icons.Rounded.AccountBalance,
              title = stringResource(R.string.service_ddo_title),
              description = stringResource(R.string.service_ddo_desc),
              onClick = onEnterPortal,
              testTag = "service_ddo_card",
            )
            ServiceItemCard(
              icon = Icons.Rounded.Description,
              title = stringResource(R.string.service_payslip_title),
              description = stringResource(R.string.service_payslip_desc),
              onClick = onEnterPortal,
              testTag = "service_payslip_card",
            )
            ServiceItemCard(
              icon = Icons.Rounded.Lock,
              title = stringResource(R.string.service_security_title),
              description = stringResource(R.string.service_security_desc),
              onClick = onOpenGuide,
              testTag = "service_security_card",
            )
          }

          Spacer(modifier = Modifier.height(8.dp))
        }
      }
    }
  }
}

@Composable
private fun PrimaryPortalCard(
  onEnterPortal: () -> Unit,
  onOpenExternal: () -> Unit,
  onOpenGuide: () -> Unit,
) {
  Card(
    modifier = Modifier.fillMaxWidth(),
    shape = MaterialTheme.shapes.large,
    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
    elevation = CardDefaults.cardElevation(defaultElevation = 3.dp),
  ) {
    Column(
      modifier = Modifier.fillMaxWidth().padding(20.dp),
      verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
      Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp),
      ) {
        Surface(
          color = MaterialTheme.colorScheme.primaryContainer,
          shape = RoundedCornerShape(12.dp),
          modifier = Modifier.size(44.dp),
        ) {
          Box(contentAlignment = Alignment.Center) {
            Icon(
              imageVector = Icons.Rounded.Public,
              contentDescription = null,
              tint = MaterialTheme.colorScheme.primary,
              modifier = Modifier.size(24.dp),
            )
          }
        }
        Column(modifier = Modifier.weight(1f)) {
          Text(
            text = stringResource(R.string.portal_card_title),
            style = MaterialTheme.typography.titleLarge,
            color = MaterialTheme.colorScheme.onSurface,
          )
          Text(
            text = PifraViewModel.PIFRA_DDO_ALV_URL,
            style = MaterialTheme.typography.labelMedium,
            color = MaterialTheme.colorScheme.primary,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
          )
        }
      }

      Text(
        text = stringResource(R.string.portal_card_description),
        style = MaterialTheme.typography.bodyMedium,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
      )

      Button(
        onClick = onEnterPortal,
        modifier =
          Modifier
            .fillMaxWidth()
            .heightIn(min = 56.dp)
            .minimumInteractiveComponentSize()
            .testTag("enter_portal_button"),
        shape = RoundedCornerShape(14.dp),
        colors =
          ButtonDefaults.buttonColors(
            containerColor = MaterialTheme.colorScheme.primary,
            contentColor = MaterialTheme.colorScheme.onPrimary,
          ),
        contentPadding = PaddingValues(horizontal = 20.dp, vertical = 14.dp),
      ) {
        Text(
          text = stringResource(R.string.enter_button_label),
          style = MaterialTheme.typography.labelLarge,
          fontWeight = FontWeight.Bold,
        )
        Spacer(modifier = Modifier.width(10.dp))
        Icon(
          imageVector = Icons.AutoMirrored.Rounded.ArrowForward,
          contentDescription = stringResource(R.string.cd_enter_portal),
          modifier = Modifier.size(20.dp),
        )
      }

      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(10.dp),
      ) {
        OutlinedButton(
          onClick = onOpenExternal,
          modifier =
            Modifier
              .weight(1f)
              .heightIn(min = 48.dp)
              .testTag("open_external_browser_button"),
          shape = RoundedCornerShape(12.dp),
          border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
        ) {
          Icon(
            imageVector = Icons.AutoMirrored.Rounded.OpenInNew,
            contentDescription = null,
            modifier = Modifier.size(18.dp),
          )
          Spacer(modifier = Modifier.width(6.dp))
          Text(
            text = stringResource(R.string.open_external_browser),
            style = MaterialTheme.typography.labelMedium,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
          )
        }

        OutlinedButton(
          onClick = onOpenGuide,
          modifier =
            Modifier
              .weight(1f)
              .heightIn(min = 48.dp)
              .testTag("open_guide_button"),
          shape = RoundedCornerShape(12.dp),
          border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
        ) {
          Icon(
            imageVector = Icons.AutoMirrored.Rounded.HelpOutline,
            contentDescription = null,
            modifier = Modifier.size(18.dp),
          )
          Spacer(modifier = Modifier.width(6.dp))
          Text(
            text = stringResource(R.string.nav_guide),
            style = MaterialTheme.typography.labelMedium,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
          )
        }
      }
    }
  }
}

@Composable
private fun ServiceItemCard(
  icon: ImageVector,
  title: String,
  description: String,
  onClick: () -> Unit,
  testTag: String,
  modifier: Modifier = Modifier,
) {
  Card(
    modifier =
      modifier
        .fillMaxWidth()
        .clip(MaterialTheme.shapes.medium)
        .clickable(onClick = onClick)
        .testTag(testTag),
    shape = MaterialTheme.shapes.medium,
    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.75f)),
    elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
  ) {
    Row(
      modifier = Modifier.fillMaxWidth().padding(14.dp),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.spacedBy(14.dp),
    ) {
      Box(
        modifier =
          Modifier
            .size(44.dp)
            .clip(RoundedCornerShape(12.dp))
            .background(MaterialTheme.colorScheme.primaryContainer),
        contentAlignment = Alignment.Center,
      ) {
        Icon(
          imageVector = icon,
          contentDescription = null,
          tint = MaterialTheme.colorScheme.primary,
          modifier = Modifier.size(22.dp),
        )
      }

      Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
        Text(
          text = title,
          style = MaterialTheme.typography.titleMedium,
          color = MaterialTheme.colorScheme.onSurface,
        )
        Text(
          text = description,
          style = MaterialTheme.typography.bodyMedium,
          color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
      }

      Icon(
        imageVector = Icons.AutoMirrored.Rounded.ArrowForward,
        contentDescription = null,
        tint = MaterialTheme.colorScheme.primary.copy(alpha = 0.7f),
        modifier = Modifier.size(18.dp),
      )
    }
  }
}
