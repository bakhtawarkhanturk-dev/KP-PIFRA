package com.example.ui

import androidx.lifecycle.ViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

sealed interface PifraDestination {
  data object Home : PifraDestination

  data class Portal(val url: String = PifraViewModel.PIFRA_DDO_ALV_URL) : PifraDestination

  data object Guide : PifraDestination
}

data class PortalUiState(
  val destination: PifraDestination = PifraDestination.Home,
  val currentUrl: String = PifraViewModel.PIFRA_DDO_ALV_URL,
  val pageTitle: String = "",
  val loadProgress: Int = 0,
  val isLoading: Boolean = false,
  val errorMessage: String? = null,
  val canGoBackInWebView: Boolean = false,
  val reloadTrigger: Int = 0,
)

class PifraViewModel : ViewModel() {

  private val _uiState = MutableStateFlow(PortalUiState())
  val uiState: StateFlow<PortalUiState> = _uiState.asStateFlow()

  fun enterPortal(url: String = PIFRA_DDO_ALV_URL) {
    _uiState.update {
      it.copy(
        destination = PifraDestination.Portal(url),
        currentUrl = url,
        isLoading = true,
        loadProgress = 10,
        errorMessage = null,
      )
    }
  }

  fun openGuide() {
    _uiState.update { it.copy(destination = PifraDestination.Guide) }
  }

  fun navigateHome() {
    _uiState.update {
      it.copy(
        destination = PifraDestination.Home,
        errorMessage = null,
        isLoading = false,
        loadProgress = 0,
      )
    }
  }

  fun updateWebProgress(progress: Int) {
    _uiState.update {
      it.copy(
        loadProgress = progress.coerceIn(0, 100),
        isLoading = progress in 1..99,
      )
    }
  }

  fun updatePageState(url: String?, title: String?, canGoBack: Boolean) {
    _uiState.update { state ->
      state.copy(
        currentUrl = url?.takeIf { it.isNotBlank() } ?: state.currentUrl,
        pageTitle = title.orEmpty(),
        canGoBackInWebView = canGoBack,
        isLoading = false,
        loadProgress = 100,
      )
    }
  }

  fun onWebError(message: String) {
    _uiState.update {
      it.copy(
        isLoading = false,
        loadProgress = 0,
        errorMessage = message,
      )
    }
  }

  fun triggerReload() {
    _uiState.update {
      it.copy(
        errorMessage = null,
        isLoading = true,
        loadProgress = 10,
        reloadTrigger = it.reloadTrigger + 1,
      )
    }
  }

  companion object {
    const val PIFRA_DDO_ALV_URL = "https://m.pifra.gov.pk/DDOALV"
  }
}
