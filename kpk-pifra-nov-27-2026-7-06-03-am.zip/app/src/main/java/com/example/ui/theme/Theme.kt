package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.unit.dp

private val LightColorScheme =
  lightColorScheme(
    primary = KpkRoyalBlue,
    onPrimary = KpkWhite,
    primaryContainer = KpkSkyBlueContainer,
    onPrimaryContainer = KpkOnSkyBlueContainer,
    secondary = KpkBrightBlue,
    onSecondary = KpkWhite,
    secondaryContainer = KpkSurfaceVariant,
    onSecondaryContainer = KpkTextPrimary,
    tertiary = KpkGoldAccent,
    onTertiary = KpkDeepNavy,
    background = KpkOffWhiteBackground,
    onBackground = KpkTextPrimary,
    surface = KpkWhite,
    onSurface = KpkTextPrimary,
    surfaceVariant = KpkSurfaceVariant,
    onSurfaceVariant = KpkTextSecondary,
    outline = KpkOutlineBlue,
  )

private val DarkColorScheme =
  darkColorScheme(
    primary = KpkDarkPrimary,
    onPrimary = KpkDarkOnPrimary,
    primaryContainer = KpkRoyalBlue,
    onPrimaryContainer = KpkWhite,
    secondary = KpkBrightBlue,
    onSecondary = KpkWhite,
    secondaryContainer = KpkDarkSurfaceVariant,
    onSecondaryContainer = KpkDarkTextPrimary,
    tertiary = KpkGoldAccent,
    onTertiary = KpkDeepNavy,
    background = KpkDarkBackground,
    onBackground = KpkDarkTextPrimary,
    surface = KpkDarkSurface,
    onSurface = KpkDarkTextPrimary,
    surfaceVariant = KpkDarkSurfaceVariant,
    onSurfaceVariant = KpkDarkTextSecondary,
    outline = KpkDarkOutline,
  )

val KpkPifraShapes =
  Shapes(
    small = RoundedCornerShape(10.dp),
    medium = RoundedCornerShape(16.dp),
    large = RoundedCornerShape(24.dp),
  )

@Composable
fun KpkPifraTheme(
  darkTheme: Boolean = isSystemInDarkTheme(),
  content: @Composable () -> Unit,
) {
  val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme

  MaterialTheme(
    colorScheme = colorScheme,
    typography = Typography,
    shapes = KpkPifraShapes,
    content = content,
  )
}
