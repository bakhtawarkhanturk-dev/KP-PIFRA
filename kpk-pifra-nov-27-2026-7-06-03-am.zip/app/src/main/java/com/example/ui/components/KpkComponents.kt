package com.example.ui.components

import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.VerifiedUser
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.ui.theme.KpkBrightBlue
import com.example.ui.theme.KpkDeepNavy
import com.example.ui.theme.KpkGoldAccent
import com.example.ui.theme.KpkRoyalBlue
import com.example.ui.theme.KpkWhite

@Composable
fun KpkGovernmentHeroHeader(modifier: Modifier = Modifier) {
  Box(
    modifier =
      modifier
        .fillMaxWidth()
        .background(
          brush =
            Brush.verticalGradient(
              colors = listOf(KpkDeepNavy, KpkRoyalBlue, KpkBrightBlue)
            ),
          shape = RoundedCornerShape(bottomStart = 32.dp, bottomEnd = 32.dp),
        )
        .statusBarsPadding()
        .padding(horizontal = 24.dp, vertical = 24.dp),
    contentAlignment = Alignment.Center,
  ) {
    Column(
      horizontalAlignment = Alignment.CenterHorizontally,
      verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
      Box(
        modifier =
          Modifier
            .size(104.dp)
            .clip(CircleShape)
            .background(KpkWhite)
            .border(width = 3.dp, color = KpkGoldAccent, shape = CircleShape)
            .padding(6.dp),
        contentAlignment = Alignment.Center,
      ) {
        Image(
          painter = painterResource(id = R.drawable.img_kpk_emblem_1795744836848),
          contentDescription = stringResource(R.string.cd_kpk_emblem),
          contentScale = ContentScale.Fit,
          modifier = Modifier.size(88.dp).clip(CircleShape).testTag("kpk_emblem_image"),
        )
      }

      Spacer(modifier = Modifier.height(2.dp))

      Text(
        text = stringResource(R.string.gov_header_title),
        style = MaterialTheme.typography.headlineSmall,
        color = KpkWhite,
        textAlign = TextAlign.Center,
      )

      Text(
        text = stringResource(R.string.gov_header_subtitle),
        style = MaterialTheme.typography.bodyMedium,
        color = Color(0xFFD6E7FF),
        textAlign = TextAlign.Center,
      )

      Surface(
        color = Color.White.copy(alpha = 0.14f),
        shape = RoundedCornerShape(50),
        border = BorderStroke(1.dp, Color.White.copy(alpha = 0.28f)),
      ) {
        Row(
          modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp),
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(6.dp),
        ) {
          Icon(
            imageVector = Icons.Rounded.VerifiedUser,
            contentDescription = null,
            tint = KpkGoldAccent,
            modifier = Modifier.size(16.dp),
          )
          Text(
            text = stringResource(R.string.portal_badge_label),
            style = MaterialTheme.typography.labelSmall,
            color = KpkWhite,
            fontWeight = FontWeight.Bold,
          )
        }
      }
    }
  }
}

@Composable
fun PoweredByFooter(
  modifier: Modifier = Modifier,
  applyNavBarInsets: Boolean = true,
) {
  val baseModifier =
    if (applyNavBarInsets) {
      modifier.fillMaxWidth().navigationBarsPadding()
    } else {
      modifier.fillMaxWidth()
    }

  Column(
    modifier = baseModifier.background(MaterialTheme.colorScheme.surface),
    horizontalAlignment = Alignment.CenterHorizontally,
  ) {
    HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.6f))
    Row(
      modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp),
      horizontalArrangement = Arrangement.Center,
      verticalAlignment = Alignment.CenterVertically,
    ) {
      Box(
        modifier =
          Modifier.size(8.dp).clip(CircleShape).background(MaterialTheme.colorScheme.primary)
      )
      Spacer(modifier = Modifier.width(8.dp))
      Text(
        text = stringResource(R.string.footer_powered_by),
        style = MaterialTheme.typography.labelMedium,
        color = MaterialTheme.colorScheme.primary,
        fontWeight = FontWeight.SemiBold,
        modifier = Modifier.testTag("footer_powered_by"),
      )
    }
  }
}

fun openUrlInExternalBrowser(context: Context, url: String) {
  runCatching {
    val intent =
      Intent(Intent.ACTION_VIEW, Uri.parse(url)).apply {
        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
      }
    context.startActivity(intent)
  }
}
