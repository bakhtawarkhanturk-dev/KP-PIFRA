package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val KpkRoyalBlue = Color(0xFF0D47A1)
val KpkDeepNavy = Color(0xFF072F6E)
val KpkBrightBlue = Color(0xFF1565C0)
val KpkSkyBlueContainer = Color(0xFFE3F2FD)
val KpkOnSkyBlueContainer = Color(0xFF082D6B)
val KpkGoldAccent = Color(0xFFD4AF37)

val KpkWhite = Color(0xFFFFFFFF)
val KpkOffWhiteBackground = Color(0xFFF6F9FF)
val KpkSurfaceVariant = Color(0xFFEDF3FC)
val KpkOutlineBlue = Color(0xFFC8DCF6)

val KpkTextPrimary = Color(0xFF0E1E38)
val KpkTextSecondary = Color(0xFF475E7B)

// Dark theme counterparts maintaining blue identity
val KpkDarkBackground = Color(0xFF091426)
val KpkDarkSurface = Color(0xFF10203A)
val KpkDarkSurfaceVariant = Color(0xFF192E52)
val KpkDarkPrimary = Color(0xFF82B1FF)
val KpkDarkOnPrimary = Color(0xFF002B66)
val KpkDarkOutline = Color(0xFF2D4875)
val KpkDarkTextPrimary = Color(0xFFF0F5FF)
val KpkDarkTextSecondary = Color(0xFFB3C5E2)
