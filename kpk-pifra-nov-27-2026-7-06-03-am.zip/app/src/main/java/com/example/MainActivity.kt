package com.example

import android.graphics.Color as AndroidColor
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.tween
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.PifraDestination
import com.example.ui.PifraViewModel
import com.example.ui.screens.GuideScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.PortalScreen
import com.example.ui.theme.KpkPifraTheme

class MainActivity : ComponentActivity() {
  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge(
      statusBarStyle = SystemBarStyle.dark(AndroidColor.TRANSPARENT),
      navigationBarStyle = SystemBarStyle.light(AndroidColor.WHITE, AndroidColor.WHITE),
    )
    setContent {
      KpkPifraTheme {
        KpkPifraApp()
      }
    }
  }
}

@Composable
fun KpkPifraApp(viewModel: PifraViewModel = viewModel()) {
  val uiState by viewModel.uiState.collectAsStateWithLifecycle()

  Crossfade(
    targetState = uiState.destination,
    animationSpec = tween(durationMillis = 220),
    label = "pifra_screen_transition",
  ) { destination ->
    when (destination) {
      PifraDestination.Home ->
        HomeScreen(
          onEnterPortal = { viewModel.enterPortal(PifraViewModel.PIFRA_DDO_ALV_URL) },
          onOpenGuide = { viewModel.openGuide() },
        )

      is PifraDestination.Portal ->
        PortalScreen(
          uiState = uiState,
          initialUrl = destination.url,
          onNavigateHome = { viewModel.navigateHome() },
          onProgressChanged = { progress -> viewModel.updateWebProgress(progress) },
          onPageStateChanged = { url, title, canGoBack ->
            viewModel.updatePageState(url, title, canGoBack)
          },
          onWebError = { message -> viewModel.onWebError(message) },
          onRetry = { viewModel.triggerReload() },
        )

      PifraDestination.Guide ->
        GuideScreen(
          onNavigateHome = { viewModel.navigateHome() },
          onEnterPortal = { viewModel.enterPortal(PifraViewModel.PIFRA_DDO_ALV_URL) },
        )
    }
  }
}
